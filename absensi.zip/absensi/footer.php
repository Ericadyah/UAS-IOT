<div class="footer" style="text-align: center">
	CECANS
</div>