<?php 
    error_reporting(E_ALL);
    ini_set('display_errors', 1);
    include "koneksi.php";

    // Baca tabel status untuk mode absensi
    $sql = mysqli_query($konek, "SELECT * FROM status");
    $data = mysqli_fetch_array($sql);
    $mode_absen = $data['mode'];        

    // Uji mode absen
    $mode = "";
    if($mode_absen == 1)
        $mode = "Masuk";
    elseif($mode_absen == 4)
        $mode = "Pulang";

    echo "Mode absen: " . $mode . "<br>";

    // Baca tabel tmprfid
    $baca_kartu = mysqli_query($konek, "SELECT * FROM tmprfid");
    $nokartu = "";
    if(mysqli_num_rows($baca_kartu) > 0)
    {
        $data_kartu = mysqli_fetch_array($baca_kartu);
        $nokartu    = $data_kartu['nokartu'];
    }

    echo "No kartu: " . $nokartu . "<br>";
?>

<div class="container-fluid" style="text-align: center;">
    <?php if($nokartu=="") { ?>

    <h3>Absen : <?php echo $mode; ?> </h3>
    <h3>Silahkan Tempelkan Kartu RFID Anda</h3>
    <img src="images/rfid.png" style="width: 200px"> <br>
    <img src="images/animasi2.gif">

    <?php } else {
        // Cek nomor kartu RFID tersebut apakah terdaftar di tabel karyawan
        $cari_karyawan = mysqli_query($konek, "SELECT * FROM karyawan WHERE nokartu='$nokartu'");
        $jumlah_data = mysqli_num_rows($cari_karyawan);

        if($jumlah_data == 0)
            echo "<h1>Maaf! Kartu Tidak Dikenali</h1>";
        else
        {
            // Ambil nama karyawan
            $data_karyawan = mysqli_fetch_array($cari_karyawan);
            $nama = $data_karyawan['nama'];

            // Tanggal dan jam hari ini
            date_default_timezone_set('Asia/Makassar');
            $tanggal = date('Y-m-d');
            $jam     = date('H:i:s');

            echo "Nama: " . $nama . "<br>";
            echo "Tanggal: " . $tanggal . "<br>";
            echo "Jam: " . $jam . "<br>";

            // Cek di tabel absensi, apakah nomor kartu tersebut sudah ada sesuai tanggal saat ini. Apabila belum ada, maka dianggap absen masuk, tapi kalau sudah ada, maka update data sesuai mode absensi
            $cari_absen = mysqli_query($konek, "SELECT * FROM absensi WHERE nokartu='$nokartu' AND tanggal='$tanggal'");
            // Hitung jumlah datanya
            $jumlah_absen = mysqli_num_rows($cari_absen);
            echo "Jumlah absen: " . $jumlah_absen . "<br>";

            if($jumlah_absen == 0)
            {
                echo "<h1>Selamat Datang <br> $nama</h1>";
                $insert_query = "INSERT INTO absensi(nokartu, tanggal, jam_masuk) VALUES('$nokartu', '$tanggal', '$jam')";
                if (mysqli_query($konek, $insert_query)) {
                    echo "Absen masuk tercatat.<br>";
                } else {
                    echo "Error: " . mysqli_error($konek) . "<br>";
                }
            }
            else
            {
                // Update sesuai pilihan mode absen
                if($mode_absen == 4)
                {
                    echo "<h1>Selamat Jalan <br> $nama</h1>";
                    $update_query = "UPDATE absensi SET jam_pulang='$jam' WHERE nokartu='$nokartu' AND tanggal='$tanggal'";
                    if(mysqli_query($konek, $update_query)) {
                        echo "Jam pulang tercatat.<br>";
                    } else {
                        echo "Error: " . mysqli_error($konek) . "<br>";
                    }
                }
            }
        }

        // Kosongkan tabel tmprfid
        mysqli_query($konek, "DELETE FROM tmprfid");
        echo "Tabel tmprfid dikosongkan.<br>";
    } ?>

</div>
